import { Arg, Mutation, Resolver } from 'type-graphql';
import { AuthService } from './auth.service';
import { SignupInput, SignupOutput } from './dtos/signup.dto';

@Resolver()
export class AuthResolver {
  private authService = new AuthService();

  @Mutation(() => SignupOutput)
  async signup(@Arg('data', () => SignupInput) data: SignupInput) {
    return this.authService.signup(data);
  }
}
