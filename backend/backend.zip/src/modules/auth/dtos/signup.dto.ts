import { Field, InputType, ObjectType } from 'type-graphql';
import { UserModel } from '../models/user.model';

@InputType()
export class SignupInput {
  @Field(() => String)
  name!: string;

  @Field(() => String)
  email!: string;

  @Field(() => String)
  password!: string;
}

@ObjectType()
export class SignupOutput {
  @Field()
  token!: string;

  @Field()
  refreshToken!: string;

  @Field(() => UserModel)
  user!: UserModel;
}
