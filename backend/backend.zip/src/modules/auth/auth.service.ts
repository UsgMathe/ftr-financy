import { User } from '@/generated/prisma/browser';
import { prismaClient } from '@/prisma/prisma.client';
import { ConflictError } from '@/shared/errors/conflict.error';
import { UnauthorizedError } from '@/shared/errors/unauthorized.error';
import { comparePassword, hashPassword } from '@/shared/utils/hash.utils';
import { signJwt } from '@/shared/utils/jwt.utils';

import { LoginInput } from './dtos/signin.dto';
import { SignupInput } from './dtos/signup.dto';

export class AuthService {
  async signup(data: SignupInput) {
    const existingUser = await prismaClient.user.findUnique({
      where: {
        email: data.email,
      },
    });

    if (existingUser) {
      throw new ConflictError('Email already in use');
    }

    const user = await prismaClient.user.create({
      data: {
        name: data.name,
        email: data.email,
        password: await hashPassword(data.password),
      },
    });

    return this.generateTokens(user);
  }

  async login(data: LoginInput) {
    const user = await prismaClient.user.findUnique({
      where: {
        email: data.email,
      },
    });

    if (!user?.password) {
      throw new UnauthorizedError();
    }

    const isPasswordValid = await comparePassword(data.password, user.password);

    if (!isPasswordValid) {
      throw new UnauthorizedError();
    }

    return this.generateTokens(user);
  }

  private generateTokens(user: User) {
    const payload = {
      id: user.id,
      email: user.email,
    };

    const { password, ...safeUser } = user;

    return {
      accessToken: signJwt(payload, '15m'),
      refreshToken: signJwt(payload, '7d'),
      user: safeUser,
    };
  }
}
