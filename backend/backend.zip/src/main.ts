import 'reflect-metadata';

import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@as-integrations/express5';
import express from 'express';
import { buildSchema } from 'type-graphql';

import { env } from './shared/utils/env.utils';
import { errorHandler } from './shared/middlewares/error-handler.middleware';
import { UserResolver } from './modules/user/user.resolver';

async function main() {
  const app = express();
  app.use(errorHandler);

  const schema = await buildSchema({
    resolvers: [UserResolver],
    validate: false,
    emitSchemaFile: './schema.graphql',
  });

  const server = new ApolloServer({ schema });

  await server.start();

  app.use('/graphql', express.json(), expressMiddleware(server));

  app.listen(env.PORT, () => {
    console.log(`🚀 Server ready at: http://localhost:${env.PORT}/graphql`);
  });
}

main();
